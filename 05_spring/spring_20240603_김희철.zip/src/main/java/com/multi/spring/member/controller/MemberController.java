package com.multi.spring.member.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.multi.spring.member.model.dto.MemberDTO;
import com.multi.spring.member.service.MemberService;

@Controller
@RequestMapping("/member")
public class MemberController {
	private final MemberService memberService;
	@Autowired
	public MemberController(MemberService memberService) {
		this.memberService = memberService;
	}
	
	@RequestMapping("/main")
	public String main() {
		return "redirect:/index.jsp";
	}
	
	@RequestMapping("/member")
	public void memberMain() {
		
	}
	
	@RequestMapping("/insert_form")
	public void insertForm() {
		
	}
	
	@RequestMapping("/delete_form")
	public void deleteForm() {
		
	}
	
	@RequestMapping("/update_form")
	public void updateForm() {
		
	}
	
	@RequestMapping("/one_form")
	public void oneForm() {
		
	}
	
	@RequestMapping("/one")
	public void memberOne() {
		
	}
	
	@PostMapping("/insert")
	public String insertMember(MemberDTO memberDTO, HttpSession session) throws Exception {
		
		System.out.println("insert ==> " + memberDTO);
		
		memberService.insertMember(memberDTO);
		
		session.setAttribute("msg", "회원가입성공");
		
		return "redirect:/member/member";
	}

	@GetMapping("/list")
	public void listMembers(Model model) throws Exception {
		
        List<MemberDTO> list = memberService.selectList();
        
        model.addAttribute("list", list);
    }
	
	@GetMapping("/delete")
    public String deleteMember(String id, HttpSession session) throws Exception {
		
        memberService.deleteMember(id);
        
        session.setAttribute("msg", "회원삭제성공");
        
        return "redirect:/member/member";
    }
	
	@PostMapping("/update")
	public String updateMember(MemberDTO memberDTO, HttpSession session) throws Exception {
        memberService.updateMember(memberDTO);
        
        session.setAttribute("msg", "회원정보수정성공");
        
        return "redirect:/member/member";
    }
	
	@GetMapping("/one")
    public void selectMember(String id, Model model) throws Exception {
        MemberDTO member = memberService.selectMember(id);
        
        model.addAttribute("dto", member);
    }
}