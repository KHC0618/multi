package com.multi.practice;

public class Academy {
    public static void main(String[] args) {
        Enrolment sub1 = new Enrolment("자바", "14:30", "홍길동");
        Enrolment sub2 = new Enrolment("JSP", "9:30", "홍길동");
        System.out.println(sub1);
        System.out.println(sub2);
    }
}
