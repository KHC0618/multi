function travel() {
    alert("travel 함수가 실행되었습니다.")
}

function rest() {
    alert("rest 함수가 실행되었습니다.")
}

function fight() {
    alert("파이팅!! alert!")
}

function bye() {
    alert("잘가!! 안녕!! alert!")
}

function go() {
    for(let i = 0; i < 100; i++) {
        document.write(i + 1 + "<br>")
    }
}