package com.multi.practice;

public class Calculator2 {
    public int sum(int count, int price) {
        return count * price;
    }

    public int div(int sum, int person) {
        return sum / person;
    }

    public int total(int sum, int sum2) {
        return sum + sum2;
    }
}
